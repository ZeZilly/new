import { Contact as ContactSection } from "@/components/sections/Contact";

export default function Contact() {
  return (
    <main className="pt-16">
      <ContactSection />
    </main>
  );
}
