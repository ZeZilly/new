import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import { tr } from "date-fns/locale";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

const services = [
  { id: "cilt-bakimi", name: "Cilt Bakımı", duration: 60 },
  { id: "epilasyon", name: "Epilasyon", duration: 45 },
  { id: "makyaj", name: "Makyaj", duration: 60 }
];

export default function Booking() {
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [selectedService, setSelectedService] = useState<string>();
  const { toast } = useToast();

  const { data: availableSlots, isLoading: slotsLoading } = useQuery({
    queryKey: ["/api/calendar/available-slots", selectedDate?.toISOString()],
    enabled: !!selectedDate,
  });

  const bookingMutation = useMutation({
    mutationFn: async (data: { date: string, service: string }) => {
      const response = await fetch("/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Randevu oluşturulamadı");
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Randevu Oluşturuldu",
        description: "Randevunuz başarıyla oluşturuldu. Email ile bilgilendirme alacaksınız.",
      });
    },
    onError: (error) => {
      toast({
        title: "Hata",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleBooking = (time: string) => {
    if (!selectedDate || !selectedService) return;

    const dateTime = new Date(selectedDate);
    const [hours, minutes] = time.split(":");
    dateTime.setHours(parseInt(hours), parseInt(minutes));

    bookingMutation.mutate({
      date: dateTime.toISOString(),
      service: selectedService,
    });
  };

  return (
    <main className="pt-24 px-4 min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-serif mb-8 text-center">Online Randevu</h1>

        <div className="grid md:grid-cols-2 gap-8">
          <Card>
            <CardContent className="pt-6">
              <h2 className="text-xl font-medium mb-4">1. Hizmet Seçin</h2>
              <div className="space-y-2">
                {services.map((service) => (
                  <Button
                    key={service.id}
                    variant={selectedService === service.id ? "default" : "outline"}
                    className="w-full justify-start"
                    onClick={() => setSelectedService(service.id)}
                  >
                    {service.name} ({service.duration} dk)
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <h2 className="text-xl font-medium mb-4">2. Tarih Seçin</h2>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                locale={tr}
                disabled={{ before: new Date() }}
                className="rounded-md border"
              />
            </CardContent>
          </Card>

          {selectedDate && selectedService && (
            <Card className="md:col-span-2">
              <CardContent className="pt-6">
                <h2 className="text-xl font-medium mb-4">3. Saat Seçin</h2>
                {slotsLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin" />
                  </div>
                ) : availableSlots?.length > 0 ? (
                  <div className="grid grid-cols-4 gap-2">
                    {availableSlots.map((slot: string) => (
                      <Button
                        key={slot}
                        variant="outline"
                        onClick={() => handleBooking(slot)}
                        disabled={bookingMutation.isPending}
                      >
                        {slot}
                      </Button>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-gray-500">
                    Seçilen tarih için uygun saat bulunamadı.
                  </p>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </main>
  );
}