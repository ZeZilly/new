import { ScrollReveal } from "@/components/ui/ScrollReveal";

export default function Privacy() {
  return (
    <main className="pt-20 px-4 min-h-screen bg-gray-50">
      <div className="max-w-3xl mx-auto py-12">
        <ScrollReveal>
          <h1 className="text-4xl font-serif mb-8">Gizlilik Politikası</h1>
          
          <div className="prose prose-gray">
            <p>
              Shining Beauty & Wellness olarak kişisel verilerinizin güvenliği bizim için önemlidir. 
              Bu gizlilik politikası, hizmetlerimizi kullanırken toplanan bilgilerin nasıl kullanıldığını açıklar.
            </p>

            <h2>Toplanan Bilgiler</h2>
            <p>
              Hizmetlerimizi kullanırken aşağıdaki bilgiler toplanabilir:
              - İsim ve iletişim bilgileri
              - Randevu bilgileri
              - Sağlık geçmişi ve tercihler
            </p>

            <h2>Bilgilerin Kullanımı</h2>
            <p>
              Topladığımız bilgiler şu amaçlarla kullanılır:
              - Hizmet kalitemizi iyileştirmek
              - Randevularınızı yönetmek
              - Sizinle iletişim kurmak
              - Yasal yükümlülüklerimizi yerine getirmek
            </p>

            <h2>Bilgi Güvenliği</h2>
            <p>
              Kişisel verileriniz güvenli sistemlerde saklanır ve yetkisiz erişime karşı korunur.
              Bilgileriniz yalnızca hizmet sağlamak için gerekli olan personel ile paylaşılır.
            </p>
          </div>
        </ScrollReveal>
      </div>
    </main>
  );
}
