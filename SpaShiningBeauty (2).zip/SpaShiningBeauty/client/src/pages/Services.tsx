import { Services as ServicesSection } from "@/components/sections/Services";

export default function Services() {
  return (
    <main className="pt-16">
      <ServicesSection />
    </main>
  );
}
