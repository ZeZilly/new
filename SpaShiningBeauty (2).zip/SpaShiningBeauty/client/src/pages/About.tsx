import { About as AboutSection } from "@/components/sections/About";

export default function About() {
  return (
    <main className="pt-16">
      <AboutSection />
    </main>
  );
}
