import { ScrollReveal } from "@/components/ui/ScrollReveal";

export default function Terms() {
  return (
    <main className="pt-20 px-4 min-h-screen bg-gray-50">
      <div className="max-w-3xl mx-auto py-12">
        <ScrollReveal>
          <h1 className="text-4xl font-serif mb-8">Kullanım Koşulları</h1>
          
          <div className="prose prose-gray">
            <p>
              Shining Beauty & Wellness hizmetlerini kullanarak aşağıdaki koşulları kabul etmiş olursunuz.
            </p>

            <h2>Randevu Politikası</h2>
            <p>
              - Randevular en az 24 saat önceden iptal edilmelidir
              - Geç iptal veya gelmeme durumunda ücret talep edilebilir
              - Randevu saatine lütfen zamanında geliniz
            </p>

            <h2>Hizmet Kuralları</h2>
            <p>
              - Sağlık durumunuzu lütfen önceden bildiriniz
              - Terapi öncesi ve sonrası tavsiyelere uyunuz
              - Merkezimizin hijyen kurallarına uyunuz
            </p>

            <h2>Ödeme Koşulları</h2>
            <p>
              - Ödeme hizmet öncesinde yapılmalıdır
              - Kabul edilen ödeme yöntemleri: Nakit, kredi kartı
              - Kampanya ve indirimler özel koşullara tabidir
            </p>
          </div>
        </ScrollReveal>
      </div>
    </main>
  );
}
